#2.	

""" Write a Python program that implements the Fahrenheit to Celsius algorithm. """

fahrenheit = float(input("Enter Fahrenheit temperature: "))
celsius = 5/9 * (fahrenheit - 32)
print(celsius)